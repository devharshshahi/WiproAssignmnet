
class Animal
{
	void eat() {
		System.out.println("eat method of animal class");
	}
	void sleep() {
		System.out.println("sleep method of animal class");
	}
}
class Bird extends Animal
{
	void eat()
	{
		System.out.println("eat method of bird class");
	}
	void sleep()
	{
		System.out.println("sleep method of bird class");
	}
	void fly()
	{
		System.out.println("fly method of bird class");
	}
	
}




public class program1 {

	public static void main(String[] args) {
	Animal obj=new Animal();
	Bird obj1=new Bird();
	obj.eat();
	obj.sleep();
	obj1.eat();
	obj1.sleep();
	obj1.fly();

	}

}
