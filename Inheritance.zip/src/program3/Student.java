package program3;

public class Student extends Person{
	int studentId;
	Student(String name,String dateOfBirth,int studentId)
	{
		super(name, dateOfBirth);
		this.studentId=studentId;
	}
void display()
{
	
	System.out.println("Studnetid is: "+studentId);
}
}
