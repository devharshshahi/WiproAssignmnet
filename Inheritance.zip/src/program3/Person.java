package program3;

public class Person {
	String name;
	String dateOfBirth;
	
	Person(String name,String dateOfBirth)
	{
		this.name=name;
		this.dateOfBirth=dateOfBirth;
	}
	void display()
	{
		System.out.println("Name:"+name);
		System.out.println("Date Of Birth:"+dateOfBirth);
	}

}
