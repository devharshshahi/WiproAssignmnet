package program3;

public class College_student extends Student {
	String collegename;
	String year;
	College_student(int studentId,String collegename,String year)
	{
		super(collegename, year, studentId);
		this.collegename=collegename;
		this.year=year;
	}
void display()
{
	
	System.out.println("college name is: "+collegename);
	System.out.println("year in which student is studing: "+year);
}
}
