package program3;


public class Test {

	public static void main(String[] args) {
		Person obj1=new Person("John", "12/12/1998");
		Teacher obj2=new Teacher("John", "12/12/1998", 40000, "java");
		Student obj3=new Student("John", "12/12/1998",1);
		College_student obj4=new College_student(1,"saint stephen college", "fourth"); 
			obj1.display();
			obj2.display();
			obj3.display();
			obj4.display();
	}

}
