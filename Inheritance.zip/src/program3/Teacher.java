package program3;

public class Teacher extends Person{
	double salary;
	String subject;
	Teacher(String name,String dateOfBirth,double salary,String subject)
	{
		super(name, dateOfBirth);
		this.salary=salary;
		this.subject=subject;
	}
	void display()
	{
		
		System.out.println("salary of teacher: "+salary);
		System.out.println("Subject That the teacher teach: "+subject);
	}

}
