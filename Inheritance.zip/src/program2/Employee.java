package program2;
public class Employee extends Person{
 double annualsalary;
 int employeestartwork;
 String insuranceno;	
	Employee()
	{
		
	}
	public void setannualsalary(double annualsalary)
	{
		this.annualsalary=annualsalary;
	}
	public double getannualsalary()
	{
		return annualsalary;
	}
	public void setemployeestartwork(int employeestartwork)
	{
		this.employeestartwork=employeestartwork;
	}
	public int getemployeestartwork()
	{
		return employeestartwork;
	}
	public void setinsuranceno(String insranceno)
	{
		this.insuranceno=insranceno;
	}
	public String getinsuranceno()
	{
		return insuranceno;
	}
	
}
