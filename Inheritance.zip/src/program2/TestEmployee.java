package program2;

public class TestEmployee {

	public static void main(String[] args) {
		Employee emp=new Employee();
		Person per=new Person();
		emp.setannualsalary(400000);
		emp.setemployeestartwork(2004);
		emp.setinsuranceno("ABGSF4578");
		per.setname("John");
		System.out.println("Employee Name: "+per.getname());
		System.out.println("Employee Annaul salary: "+emp.getannualsalary());
		System.out.println("Employee wokring start Year: "+emp.getemployeestartwork());
		System.out.println("Employee Nationl Insurance Number: "+emp.getinsuranceno());
		
	}

}
