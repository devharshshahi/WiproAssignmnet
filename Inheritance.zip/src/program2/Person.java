package program2;

public class Person {
 String name;
 
 public void setname(String name)
	{
		this.name=name;
	}
	public String getname()
	{
		return name;
	}
 
}
