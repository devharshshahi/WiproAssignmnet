package wrapper_classes;

class Employee implements Cloneable{
	int employeeid;
	String name;
	Employee Clonetest() {
		try {
			return(Employee) super.clone();
		}
		catch(CloneNotSupportedException e){
			System.out.print("clone not supported");
			return this;
		}
		
	}
}

public class program4 {

	public static void main(String[] args) {
		Employee emp=new Employee();
		Employee emp1;
		emp.employeeid=1;
		emp.name="John";
		emp1=emp.Clonetest();
		
		System.out.println("emp :"+emp.employeeid+ " "+emp.name);
		System.out.println("emp1 :"+emp1.employeeid+ " "+emp1.name);
		emp.employeeid=2;
		emp.name="smith";
		System.out.println("emp :"+emp.employeeid+ " "+emp.name);
		System.out.println("emp1 :"+emp1.employeeid+ " "+emp1.name);

	}

}
