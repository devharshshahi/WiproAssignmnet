package wrapper_classes;

import java.util.Scanner;

public class program3 {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("please enter the integer value: ");
	int number=sc.nextInt();
	String result=Integer.toBinaryString(number);
	int num=Integer.parseInt(result);
	String binary=String.format("%08d",num);
	
	System.out.println(binary);
	
	}

}
