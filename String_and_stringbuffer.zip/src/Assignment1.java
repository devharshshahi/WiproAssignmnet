import java.util.Scanner;

public class Assignment1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter the string for checking palindrome:");
		String str=sc.nextLine();
		String reverse=new StringBuffer(str).reverse().toString();
		if(str.equals(reverse))
		{
			System.out.println("string is palindrome");
		}
		else
			System.out.println("String is not palindrome");

	}

}
