import java.util.Scanner;

public class program5 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("please enter the String:");
		String str=sc.nextLine();
		System.out.println(str.substring(1, str.length()-1));

	}

}
