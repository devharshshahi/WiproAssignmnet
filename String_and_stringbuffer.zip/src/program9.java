
public class program9 {

	public static void main(String[] args) {
		String str=args[0];
		String str1=args[1];
		StringBuilder result=new StringBuilder();
		 for (int i = 0; i < str.length() || i < str1.length(); i++) 
		 { 
			  
	            if (i < str.length()) 
	            {
	            	result.append(str.charAt(i)); 
	            }
	           
	            if (i < str1.length()) 
	            {
	            	 result.append(str1.charAt(i)); 
	            }
	               
	        } 
		 System.out.print(result);

	}

}
