import java.util.Scanner;

public class program8 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("please enter the string ");
		String str=sc.nextLine();
		String result="";
		int pass=-1;
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='*')
			{
				result=result.replace(Character.toString(result.charAt(result.length()-1)),"");
				pass=i+1;
			}
			if(i==pass) {
				continue;
			}
			else
			{
				result=result+str.charAt(i);
			}
		}
		System.out.println(result);
	}

}
