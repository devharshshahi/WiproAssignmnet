import java.util.Scanner;

public class program2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("please enter the frist string : ");
		String str=sc.next();
		System.out.print("please enter the second string : ");
		String str1=sc.next();
		int length=str.length();
		
		if(str.charAt(str.length()-1)==str1.charAt(0))
		{
			System.out.print(str+""+str1.substring(1));
		}
		else
		{
			String result=str.concat(str1).toLowerCase();
			System.out.print(result);
		}

	}
			
}
