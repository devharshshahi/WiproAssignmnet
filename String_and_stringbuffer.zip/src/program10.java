import java.util.Scanner;

public class program10 {

	public static void main(String[] args) {
		String str=args[0];
		int number=Integer.parseInt(args[1]);
		for(int i=0;i<number;i++)
		{
			System.out.print(str.substring(str.length()-number, str.length()));
		}
		
		
		
	}

}
