import java.util.Scanner;

public class program6 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter the first String");
		String str=sc.nextLine();
		System.out.println("please enter the second string");
		String str1=sc.nextLine();
			int strlength=str.length();
			int str1length=str1.length();
			if(strlength<str1length)
			{
				System.out.println(str+""+str1+""+str);
			}
			else
			{
				System.out.println(str1+""+str+""+str1);
			}


	}

}
