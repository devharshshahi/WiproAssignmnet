import java.util.Scanner;

public class program3 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter the String: ");
		String s1=sc.nextLine();
		for(int i=0;i<s1.length();i++)
		{
			System.out.print(s1.charAt(0)+""+s1.charAt(1));
			
		}
		
			
		
	}

}
