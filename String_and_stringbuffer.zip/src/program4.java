import java.util.*;
public class program4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("please enter the String:");
		String s1=sc.nextLine();
		int length=s1.length();
		if(length%2==0)
		{
			System.out.print(s1.substring(0, length/2));
		}
		else
			System.out.print("null");
			

	}

}
