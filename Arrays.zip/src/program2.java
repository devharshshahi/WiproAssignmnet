import java.util.Scanner;

public class program2 {

	public static void main(String[] args) {
		int size;
		
		Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        size = s.nextInt();
        int array[] = new int[size];
       
        System.out.println("Enter all the elements:");
        for(int i = 0; i < size ; i++)
        {
            array[i] = s.nextInt();
        }
        int maxvalue=array[0];
        int minvalue=array[0];
        for(int i=0;i<array.length;i++)
        {
        if(array[i]>maxvalue)
        {
        	maxvalue=array[i];
        	
        }
        
        }
        System.out.println("maximum value is: "+maxvalue);
        for(int i=0;i<array.length;i++)
        {
        if(array[i]<minvalue)
        {
        	minvalue=array[i];
        	
        }
       
        }
        System.out.println("minimum value is: "+minvalue);
}
}
