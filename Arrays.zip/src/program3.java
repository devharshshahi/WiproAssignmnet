import java.util.Scanner;

public class program3 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        int size = s.nextInt();
        int array[] = new int[size];
       
        System.out.println("Enter all the elements:");
        for(int i = 0; i < size ; i++)
        {
            array[i] = s.nextInt();
        }
        System.out.println("Enter the element you want to search in array:");
        int number=s.nextInt();
        int len=array.length;
        int i=0;
        while(i<len)
        {
        if(array[i]==number) 
        {
        	System.out.println(""+i);
        
        	return;
        }
    	i=i+1;
        	
        }
    	System.out.println("-1");
       
        
	}

}
