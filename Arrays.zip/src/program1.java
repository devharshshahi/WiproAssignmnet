import java.util.Scanner;

public class program1 {

	public static void main(String[] args) {
		 int n, sum = 0;
	        float average;
		        Scanner s = new Scanner(System.in);
		        System.out.print("Enter no. of elements you want in array:");
		        n = s.nextInt();
		        int array[] = new int[n];
		        System.out.println("Enter all the elements:");
		        for(int i = 0; i < n ; i++)
		        {
		            array[i] = s.nextInt();
	            sum = sum + array[i];
	        }
	        System.out.println("Sum:"+sum);
	        average = (float)sum / n;
	        System.out.println("Average:"+average);
	}

}
