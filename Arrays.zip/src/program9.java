
public class program9 {

	public static void main(String[] args) {
		int[][] arr=new int[2][2];
		
		if(args.length!=4) {
			System.out.println("Please enter 4 integer number");
			return;
		}
		for(int i=0;i<args.length;i++)
			arr[i/2][i%2]=Integer.parseInt(args[i]);
		
		System.out.println("The given array is : ");
		print(arr);
		
		arr = reverseArray(arr);
		
		System.out.println("The Reverse of array is :");
		print(arr);
	}
	
	public static int[][] reverseArray(int [][] arr){
		
		int[][] reverse_arr = new int[arr.length][arr[0].length];
		
		for(int i=0;i<arr.length;i++)
			for(int j=0;j<arr[0].length;j++)
				reverse_arr[i][j]=arr[(arr.length-1)-i][(arr[0].length-1)-j];
		
		return reverse_arr;
	}
	public static void print(int[][] arr) {
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[0].length;j++)
				System.out.print(arr[i][j]+" ");
			System.out.println();
		}
	}

}
