
public class program10 {

public static void main(String[] args) {
		
		if(args.length!=9) {
			System.out.print("please enter 9 integer Number");
			return;
		}
		
		int[][] arr =new int[3][3];
		for(int i=0;i<args.length;i++)
			arr[i/3][i%3]=Integer.parseInt(args[i]);
		
		int greatest_no = Integer.parseInt(args[0]);
		System.out.println("The given array is :");
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.printf("%3d ", arr[i][j]);
				greatest_no = (arr[i][j] > greatest_no) ? arr[i][j] : greatest_no;
			}
			System.out.println();
		}
		
		System.out.printf("The biggest number in the given array is %d", greatest_no);
	}

}
