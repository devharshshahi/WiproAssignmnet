
public class program8 {

	public static void main(String [] args) {
		int[] arr=new int[args.length];
		
		for(int i=0;i<args.length;i++)
			arr[i]=Integer.parseInt(args[i]);
		
		int sum = findSum(arr);
		
		System.out.println(sum);
		
		
	}
	
	public static int findSum(int[] arr) {
		int sum=0;
		int fake_sum=0;
		boolean flag = false;
		for(int element: arr) {
			sum+=element;
			if(element==6)
				flag=true;
			if(flag)
				fake_sum+=element;
			if(element==7)
				flag=false;
		}
		if(!flag)
			sum-=fake_sum;
		return sum;
	}
}
