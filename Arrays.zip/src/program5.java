import java.util.Scanner;

public class program5 {

	public static void main(String[] args) {
		int n;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        n = sc.nextInt();
        int arr[] = new int[n];
        System.out.println("Enter all the elements:");
        for (int i = 0; i < n; i++) 
        {
            arr[i] = sc.nextInt();
           
        }
        int largest1, largest2, temp;
        
		largest1 = arr[0];
		largest2 = arr[1];
 
		if (largest1 < largest2)
		{
			temp = largest1;
			largest1 = largest2;
			largest2 = temp;
		}
 
		for (int i = 2; i < arr.length; i++)
		{
			if (arr[i] > largest1)
			{
				largest2 = largest1;
				largest1 = arr[i];
			}
			else if (arr[i] > largest2 && arr[i] != largest1)
			{
				largest2 = arr[i];
			}
		}
		System.out.println("two largest number in array is " +largest1+ " and "+largest2);

		
		
	}

}
