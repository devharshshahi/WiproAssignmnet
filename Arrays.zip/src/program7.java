
import java.util.Arrays;
import java.util.Scanner;


public class program7 {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the size of array");
	int len=sc.nextInt();
	int arr[]=new int[len];
	System.out.println("enter the Elements of array");
	for(int i=0;i<len;i++)
	{
	arr[i]=sc.nextInt();
	}
	int temparray=arr.length;
	for(int i=0;i<temparray;i++)
	{
		for(int j=i+1;j<temparray;j++)
		{
			if(arr[i]==arr[j])
					{
						arr[j]=arr[temparray-1];
						temparray--;
						j--;
					}
		}
	}
	System.out.println("orignial array is");
	for(int i=0;i<arr.length;i++)
	{
		System.out.println(arr[i]+"\t");
	}
		int[] array=Arrays.copyOf(arr, temparray);
		System.out.println("After removal of duplicate element");
		for(int i=0;i<array.length;i++)
		{
			System.out.println(array[i]+"\t");
		}
		
	}

}
