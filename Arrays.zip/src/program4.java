
public class program4 {

	public static void main(String[] args) {
		int num[] = {65,66,67,68,69,70,71,72,73,74,75,76,77,78,90,97,122};
        String str =null;
        for(int i: num)
        {
            str = Character.toString((char)i);
            System.out.print(" "+str);

	}

}
}