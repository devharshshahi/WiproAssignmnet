package set;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.TreeSet;

public class Assignment3 {

	public static void main(String[] args) {
		  TreeSet<String> ts=new TreeSet<String>();  
		  ts.add("Hello");
		  ts.add("HI");
		  ts.add("India");
		  ts.add("Wipro");
		  ts.add("Bengalaru");
		  Collection<String> set = new TreeSet<>(Collections.reverseOrder());
		  
		  Iterator<String> itr=ts.iterator();  
		  while(itr.hasNext()){  
		   System.out.println(itr.next());  
		  }  
		  String query = "John";
			boolean result = false;
			
			while (itr.hasNext()) {
				if (itr.next().equals(query)) {
					result = true;
					break;
				}
			}
			if (result) 
				System.out.println(query + " exists");
			else 
				System.out.println(query + " doesn't exist");

	}

}
