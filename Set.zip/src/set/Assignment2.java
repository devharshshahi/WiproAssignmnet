package set;

import java.util.HashSet;
import java.util.Iterator;

public class Assignment2 {

	public static void main(String[] args) {
		HashSet<String> set=new HashSet<String>();
		set.add("John");    
        set.add("Mike");    
        set.add("Julli");   
        set.add("Hussey");  
        Iterator<String> i=set.iterator();  
        while(i.hasNext())  
        {  
        System.out.println(i.next());  
        }   
		
	}

}
