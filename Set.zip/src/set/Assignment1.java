package set;

import java.util.HashSet;
import java.util.Iterator;

public class Assignment1 {
	HashSet<String> H1=new HashSet<String>();
	public  HashSet<String> saveCountryNames(String CountryName)
	{
		 H1.add(CountryName);
		 return H1;
	}
	
	public String getCountry(String CountryName)
	{
		Iterator<String> itr=H1.iterator();
		while(itr.hasNext())
		{
			if(itr.next().equals(CountryName))
			{
				return CountryName;
			}
		}
		return null;
	}
	public static void main(String[] args) {
		Assignment1 obj=new Assignment1();
		obj.saveCountryNames("India");
		obj.saveCountryNames("China");
		obj.saveCountryNames("USA");

		System.out.println("India: " + obj.getCountry("India"));
		System.out.println("Japan: " + obj.getCountry("Japan"));		
	}

}