
public class Box {
	 double height,width,depth;

	public Box(double height,double width ,double depth) {
		this.height=height;
		this.width=width;
		this.depth=depth;
		
	}
	double volume()
	{
		double volume=height*width*depth;
		return volume;
	}

	public static void main(String[] args) {
		Box obj=new Box(12,10,13);
		System.out.println(obj.volume());

	}

}
