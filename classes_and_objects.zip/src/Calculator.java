
public class Calculator {
	
	static int PowerInt(int num1,int num2)
	{
		double power=Math.pow(num1, num2);
		int value=(int)power;
		return value;
	}
	static double powerDouble(double num1,double num2)
	{
		return Math.pow(num1, num2);
	}

	public static void main(String[] args) {
		System.out.println(Calculator.PowerInt(2, 4));
		System.out.println(Calculator.powerDouble(4, 2));

	}

}
