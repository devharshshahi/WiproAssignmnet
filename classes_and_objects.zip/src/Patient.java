
public class Patient {
	String patientName;
	static double height;
	static double weight;

	 double computeBMI(double weight,double height)
	{
		return weight/(height*height);
	}
	public static void main(String[] args) {
		Patient obj=new Patient();
		System.out.println(obj.computeBMI(55,1.5));
		
	}

}
