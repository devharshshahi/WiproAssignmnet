package list;

import java.util.*;

public class Assignment3 {

	

	public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		
		list.add("Add 1");
		list.add("Add 2");
		list.add("Add 3");
		list.add("Add 4");
		list.add("Add 5");
		
		
		printAll(list);
	}
	 public static void printAll(Collection<String> list)
	{
		Iterator<String> itr=list.iterator();
		while(itr.hasNext())
		
			System.out.println(itr.next());
		
		
	}
	
}



