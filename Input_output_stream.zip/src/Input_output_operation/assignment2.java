package Input_output_operation;
import java.io.*;
import java.util.Scanner;

public class assignment2 {

	public static void main(String[] args) throws IOException{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the input file name");
		String inputFilename = sc.nextLine();
		System.out.println("Enter the output file name");
		String outputFilename = sc.nextLine();
		
		File input=new File(inputFilename);
		File output=new File(outputFilename);
		BufferedReader in= new BufferedReader(new FileReader(input));
		BufferedWriter out= new BufferedWriter(new FileWriter(output));
		int c;
		while((c=in.read())!=-1)
		{
			out.write(c);
		}
		in.close();
		out.close();
	}

}
