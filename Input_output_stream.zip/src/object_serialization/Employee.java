package object_serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;

public class Employee implements java.io.Serializable{

	String name;
	Date dateOfBirth;
	String department;
	String designation;
	double Salary;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	Employee()
	{
		
	}
	
	public static void main(String args[])
	{
	
		Employee emp=new Employee();
		emp.name="john";
		emp.department="Developing";
		emp.designation="Software Engineer";
		emp.Salary=100000;
		
		try {
	         FileOutputStream fileOut = new FileOutputStream("data.ser");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(emp);
	         out.close();
	         fileOut.close();
	         System.out.printf("Serialized data is saved in data file");
	      } 
		catch (IOException i) {
	         i.printStackTrace();
	      }
		
		
		 Employee e = null;
	      try {
	         FileInputStream fileIn = new FileInputStream("data.ser");
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         e = (Employee) in.readObject();
	         in.close();
	         fileIn.close();
	      } catch (IOException i) {
	         i.printStackTrace();
	         return;
	      } catch (ClassNotFoundException c) {
	         System.out.println("Employee class not found");
	         c.printStackTrace();
	         return;
	      }
	      
	      System.out.println("Deserialized Employee...");
	      System.out.println("Name: " + e.name);
	      System.out.println("Date Of Birth: " + e.dateOfBirth);
	      System.out.println("Salary: " + e.Salary);
	      System.out.println("Department: " + e.department);
	      System.out.println("Designation: " + e.designation);
	}
	
	
}
