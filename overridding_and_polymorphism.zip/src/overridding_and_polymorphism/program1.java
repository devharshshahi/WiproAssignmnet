package overridding_and_polymorphism;

class Fruit{
	String name,taste,size;
	void eat()
	{
		System.out.println("name of the fruit is"+name+"Taste of the fruit is"+taste);
	}
	
	
}

class Apple extends Fruit{
	void eat()
	{
		System.out.println("Name of the fruit is Apple and Taste of the fruit is Sweet");
	}
	
}

class Orange extends Fruit{
	
	void eat()
	{
		System.out.println("Name of the fruit is Orange Taste of the fruit is Bitter");
	}
	
}
public class program1 {

	public static void main(String[] args) {
		Apple obj=new Apple();
		Orange obj1=new Orange();
		obj.eat();
		obj1.eat();
		// TODO Auto-generated method stub

	}

}
