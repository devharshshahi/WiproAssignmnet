
class Author
{
	private String name;
	private String email;
	private char gender;
Author(String name,String email,char gender)
{
	this.name=name;
	this.email=email;
	this.gender=gender;
}
public void setname(String name)
{
	this.name=name;
}
public void setemail(String email)
{
	this.email=email;
	
}
public void setgender(char gender)
{
	this.gender=gender;
}
public String getname() {
return name;	
}
public String getemail() {
	return email;
}
public char getgender()
{
	return gender;
}

}
class Book
{
   private String name;
	private double price;
	private int qtyInStock;
	
	
	
	Book(String name,double price,int qtyInStock)
	{
		this.name=name;
		this.price=price;
		this.qtyInStock=qtyInStock;
	}
	public void setname(String name)
	{
		this.name=name;
	}
	public void setprice(double price)
	{
		this.price=price;
	}
	public void setqtyInStock(int getqtyInStock)
	{
		this.qtyInStock=qtyInStock;
	}
	public String getname()
	{
		return name;
	}
	public double getprice()
	{
		return price;
		
	}
	public int getqtyInStock()
	{
		return qtyInStock;
	}
	
}

public class program1 {

	public static void main(String[] args) {
		
		Book obj=new Book("About The World",400,20);
		Author auth=new Author("John","John@gmail.com",'M');
		System.out.println("Name of Book: "+obj.getname());
		System.out.println("Price of Book(in rupees): "+obj.getprice());
		System.out.println("Quantity of Book in stock: "+obj.getqtyInStock());
		System.out.println("Author Name: "+auth.getname());
		System.out.println("Author Emailid: "+auth.getemail());
		System.out.println("Author gender: "+auth.getgender());
	}

}
