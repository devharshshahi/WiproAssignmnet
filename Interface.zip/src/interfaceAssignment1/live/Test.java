package interfaceAssignment1.live;

import interfaceAssignment1.music.Playable;
import interfaceAssignment1.music.string.Veena;
import interfaceAssignment1.music.wind.Saxophone;

public class Test {

	public static void main(String[] args) {
		Playable veena = new Veena();
		veena.play();
		
		Playable saxophone = new Saxophone();
		saxophone.play();

	}

}
