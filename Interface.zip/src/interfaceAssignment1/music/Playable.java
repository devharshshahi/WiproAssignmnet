package interfaceAssignment1.music;

public interface Playable {
	public void play();	
}
