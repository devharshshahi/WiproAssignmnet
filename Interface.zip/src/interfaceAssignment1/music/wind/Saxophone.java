package interfaceAssignment1.music.wind;

import interfaceAssignment1.music.Playable;

public class Saxophone implements Playable {

	@Override
	public void play() {
		System.out.println("playing Sexophone");
		
	}
	

}
