package abstract_classes;

import java.util.Random;

abstract class Compartment{
	
	public abstract String notice();
}

class FirstClass extends Compartment{
	
	@Override
	public String notice() {
		return "This is Firstclass compartment";
	}
	
}

class Ladies extends Compartment{
	
	@Override
	public String notice() {
		
		return "This is Ladies compartment";
	}
	
}

class General extends Compartment{
	
	@Override
	public String notice() {
		
		return "This is general compartment";
	}
}

class Luggage extends Compartment{
	
	@Override
	public String notice() {
		
		return "This is Luggage compartment";
	}
}


public class TestCompartment {
	
public static void main(String args[]) {
	Compartment arrCompartment[]=new Compartment[10];
	Random ran=new Random();
	int num=0;
	
	
		num=ran.nextInt(4);
		if(num==0)
		{
			arrCompartment[num]=new FirstClass();
		}
		else if(num==1) {
			arrCompartment[num]=new Ladies();
		}
		else if(num==2) {
			arrCompartment[num]=new General();
		}
		else {
			arrCompartment[num]=new Luggage();
		}
		
		System.out.println(arrCompartment[num].notice());

	
	
	
}

}
