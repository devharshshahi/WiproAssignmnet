package abstract_classes;

abstract class GeneralBank{
	
	abstract double getSavingsInterestRate();
	abstract double getFixedDepositInterestRate();
	
}
class ICICIBank extends GeneralBank{
	
	@Override
	double getSavingsInterestRate()
	{
		return 4 ;
	}
	@Override
	double getFixedDepositInterestRate()
	{	
		return 8.5;
		
	}
	
}

class KotMBank extends GeneralBank{
	
	@Override
	double getSavingsInterestRate()
	{
		return 6;
	}
	@Override
	double getFixedDepositInterestRate()
	{	
		return 9;
		
	}
	
}
public class program1 {

	public static void main(String[] args) {
		
		ICICIBank i=new ICICIBank();
		KotMBank k=new KotMBank();
		GeneralBank g=new KotMBank();
		GeneralBank gm=new ICICIBank();
		System.out.println("ICICI bank saving rate is: " +i.getSavingsInterestRate()+"%"+" ICICI bank fixed deposit rate: "+k.getFixedDepositInterestRate()+"%");
		System.out.println("KotMBank saving rate is: " +g.getSavingsInterestRate()+ "%"+" KotMBank fixed deposit rate: "+g.getFixedDepositInterestRate()+"%");
	}

}
