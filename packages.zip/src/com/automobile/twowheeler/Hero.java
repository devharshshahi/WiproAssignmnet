package com.automobile.twowheeler;
import com.automobile.*;


public class Hero extends vehicle{

	public int getspeed()
	{
		return 0;
	}
	public void radio()
	{
		System.out.println("provides facility to control the radio device ");
	}
	
	@Override
	public String getModelName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRegistrationNumber() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getOwnerName() {
		// TODO Auto-generated method stub
		return null;
	}
	

		
		
	}


