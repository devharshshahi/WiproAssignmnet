package com.automobile.twowheeler;
import com.automobile.*;

public class Honda extends vehicle {

	public int getspeed()
	{
		return 0;
	}
	public void cdplayer()
	{
		System.out.println("provides facility to control the cd player device which is available in the car");
	}
	
	@Override
	public String getModelName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRegistrationNumber() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getOwnerName() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
