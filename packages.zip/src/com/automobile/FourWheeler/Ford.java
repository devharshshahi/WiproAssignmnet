package com.automobile.FourWheeler;
import com.automobile.*;

public class Ford extends vehicle{

	public int speed() {
		return 80;
		
	}
	public int gps() {
		return 1;
	}
	@Override
	public String getModelName() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getRegistrationNumber() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getOwnerName() {
		// TODO Auto-generated method stub
		return null;
	}
}
