package com.automobile;

import com.automobile.FourWheeler.*;
import com.automobile.twowheeler.*;

public class test{

	public static void main(String[] args) {
		
		vehicle obj=new Hero();
		vehicle obj1=new Honda();
		vehicle obj2=new Ford();
		vehicle obj3=new Logan();
		obj.getModelName();
		obj.getOwnerName();
		obj.getRegistrationNumber();
		
		obj1.getModelName();
		obj1.getOwnerName();
		obj1.getRegistrationNumber();
		
		obj2.getModelName();
		obj2.getOwnerName();
		obj2.getRegistrationNumber();
		
		obj3.getModelName();
		obj3.getOwnerName();
		obj3.getRegistrationNumber();
	}

}
