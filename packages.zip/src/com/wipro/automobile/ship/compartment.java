package com.wipro.automobile.ship;

public class compartment {

	public static void main(String[] args) {
		int height,width,breadth;

	}

}
