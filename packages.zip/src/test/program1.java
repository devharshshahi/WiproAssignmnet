package test;
import test.foundation;

public class program1 {

	public static void main(String[] args) {
		foundation obj=new foundation();
		System.out.println("default access modifier "+obj.var2);
		System.out.println("protected access modifier "+obj.var3);
		System.out.println("public access modifier "+obj.var4);
		System.out.println("private access modifier is not accessible");
	}

}
