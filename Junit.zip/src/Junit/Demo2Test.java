package Junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class Demo2Test {
	Demo2 obj=new Demo2();

	@Test
	public void testPalindromeCheck() {
		assertTrue("Result: ", Demo2.palindromeCheck("madam"));
		assertTrue("Result: ", Demo2.palindromeCheck("mom"));
		assertTrue("Result: ", Demo2.palindromeCheck("dad"));
		assertTrue("Result: ", Demo2.palindromeCheck("malayalam"));
		assertFalse("Result: ",Demo2.palindromeCheck("kerala"));
		assertFalse("Result: ", Demo2.palindromeCheck("india"));
	}

}
