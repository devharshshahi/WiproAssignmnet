package Junit;

public class Demo1 {
	 String stringconcat(String string, String string2)
	{
		return string.concat(string2);
		
	}
	
	
}
	



