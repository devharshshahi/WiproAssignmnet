package Map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Assignment2 {

	public static void main(String[] args) {
			HashMap<String,String> hmap=new HashMap<String,String>();
			hmap.put("India","Delhi");
			hmap.put("Japan", "Tokyo");
			hmap.put("China", "Beejing");
			
			
			Set<Entry<String, String>> set = hmap.entrySet();
			Iterator<Entry<String, String>> itr = set.iterator();
			
			while (itr.hasNext()) {
				Map.Entry<String, String> me = itr.next();
				
				if (me.getKey().equals("Japan")) {
					System.out.println("Japan key exists");
					break;
				}
			}
			
			// b) Check if a particular value exists or not 
			set = hmap.entrySet();
			itr = set.iterator();
			
			while (itr.hasNext()) {
				Map.Entry<String, String> me = itr.next();
				
				if (me.getValue().equals("Delhi")) {
					System.out.println("Value Delhi exists");
					break;
				}
			}
			
			Set set1=hmap.entrySet();
			Iterator itr1=set1.iterator();
			while(itr1.hasNext())
			{
				@SuppressWarnings("rawtypes")
				Map.Entry m=(Map.Entry)itr1.next();
				System.out.println(m.getKey()+": "+m.getValue());
			}

	}

}
